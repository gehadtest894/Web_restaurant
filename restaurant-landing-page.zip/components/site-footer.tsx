export function SiteFooter() {
  return (
    <footer className="bg-ink text-ink-foreground">
      <div className="mx-auto max-w-7xl px-5 pb-10 pt-16 md:px-8">
        <div className="flex flex-col gap-10 md:flex-row md:items-end md:justify-between">
          <p className="font-serif text-7xl leading-none tracking-tight md:text-9xl">
            Olea
          </p>
          <nav aria-label="Footer">
            <ul className="flex flex-wrap gap-x-8 gap-y-3 text-sm text-ink-foreground/75">
              <li><a href="#story" className="hover:text-ink-foreground">Our Story</a></li>
              <li><a href="#menu" className="hover:text-ink-foreground">Menu</a></li>
              <li><a href="#reserve" className="hover:text-ink-foreground">Reservations</a></li>
              <li><a href="#visit" className="hover:text-ink-foreground">Hours & Location</a></li>
              <li>
                <a
                  href="https://instagram.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-ink-foreground"
                >
                  Instagram
                </a>
              </li>
            </ul>
          </nav>
        </div>
        <div className="mt-12 flex flex-col gap-2 border-t border-ink-foreground/15 pt-6 text-xs text-ink-foreground/55 sm:flex-row sm:justify-between">
          <p>&copy; {new Date().getFullYear()} Olea Kitchen. All rights reserved.</p>
          <p>1184 Valencia St, San Francisco · (415) 555-0142</p>
        </div>
      </div>
    </footer>
  )
}
