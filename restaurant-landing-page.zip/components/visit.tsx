const hours = [
  { days: 'Monday', time: 'Closed' },
  { days: 'Tuesday – Thursday', time: '5:00 – 10:00 pm' },
  { days: 'Friday – Saturday', time: '5:00 – 11:30 pm' },
  { days: 'Sunday Brunch', time: '10:30 am – 3:00 pm' },
  { days: 'Sunday Dinner', time: '5:00 – 9:30 pm' },
]

export function Visit() {
  return (
    <section id="visit" className="scroll-mt-20 py-20 md:py-32">
      <div className="mx-auto grid max-w-7xl gap-14 px-5 md:grid-cols-12 md:px-8">
        <div className="md:col-span-5">
          <p className="text-xs uppercase tracking-[0.25em] text-primary">
            Visit
          </p>
          <h2 className="mt-5 font-serif text-4xl leading-tight md:text-6xl">
            Find us on Valencia Street.
          </h2>
          <address className="mt-8 not-italic text-lg leading-relaxed text-muted-foreground">
            1184 Valencia Street
            <br />
            San Francisco, CA 94110
          </address>
          <a
            href="https://maps.google.com/?q=1184+Valencia+Street+San+Francisco"
            target="_blank"
            rel="noopener noreferrer"
            className="mt-6 inline-flex text-sm font-medium text-primary underline underline-offset-4 hover:no-underline"
          >
            Get directions
          </a>
        </div>

        <div className="md:col-span-6 md:col-start-7">
          <h3 className="text-xs uppercase tracking-[0.25em] text-muted-foreground">
            Hours
          </h3>
          <dl className="mt-4 divide-y divide-border border-y border-border">
            {hours.map((row) => (
              <div
                key={row.days}
                className="flex items-baseline justify-between gap-4 py-5"
              >
                <dt className="font-serif text-xl">{row.days}</dt>
                <dd className="text-right text-muted-foreground">{row.time}</dd>
              </div>
            ))}
          </dl>
          <p className="mt-6 text-sm text-muted-foreground">
            Happy hour at the bar Tuesday through Friday, 5 &ndash; 6:30 pm.
          </p>
        </div>
      </div>
    </section>
  )
}
