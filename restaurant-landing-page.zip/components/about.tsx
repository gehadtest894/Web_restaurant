import Image from 'next/image'

const stats = [
  { value: '40+', label: 'Local farms & fishers' },
  { value: '900°', label: 'Olive wood fire' },
  { value: '120', label: 'Natural wines' },
]

export function About() {
  return (
    <section id="story" className="scroll-mt-20 py-20 md:py-32">
      <div className="mx-auto grid max-w-7xl gap-12 px-5 md:grid-cols-12 md:gap-8 md:px-8">
        <div className="md:col-span-5">
          <p className="text-xs uppercase tracking-[0.25em] text-primary">
            Our Story
          </p>
          <h2 className="mt-5 text-balance font-serif text-4xl leading-[1.05] md:text-6xl">
            Everything here passes through the fire.
          </h2>
        </div>

        <div className="flex flex-col gap-6 text-lg leading-relaxed text-muted-foreground md:col-span-6 md:col-start-7 md:pt-12">
          <p>
            Olea began with a single brick oven and a stubborn idea: that the
            simplest food, cooked honestly over wood, is the most memorable.
            Chef Marisol Amari grew up between Crete and Marseille, and her
            menu follows the coastlines she knows by heart.
          </p>
          <p>
            We change the menu with the market, bake our bread twice daily, and
            press our own olive oil each autumn with a small grove in the
            hills. Come hungry, stay late.
          </p>
        </div>
      </div>

      <div className="mx-auto mt-16 grid max-w-7xl gap-8 px-5 md:mt-24 md:grid-cols-12 md:px-8">
        <div className="relative aspect-[4/5] overflow-hidden rounded-lg md:col-span-7 md:aspect-[16/11]">
          <Image
            src="/images/kitchen.png"
            alt="A chef sliding a pan into the glowing wood-fired oven"
            fill
            sizes="(min-width: 768px) 58vw, 100vw"
            className="object-cover"
          />
        </div>

        <dl className="flex flex-col justify-end divide-y divide-border border-y border-border md:col-span-4 md:col-start-9">
          {stats.map((stat) => (
            <div
              key={stat.label}
              className="flex items-baseline justify-between gap-4 py-6"
            >
              <dt className="text-sm text-muted-foreground">{stat.label}</dt>
              <dd className="font-serif text-4xl md:text-5xl">{stat.value}</dd>
            </div>
          ))}
        </dl>
      </div>
    </section>
  )
}
