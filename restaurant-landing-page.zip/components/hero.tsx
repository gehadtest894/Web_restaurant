import Image from 'next/image'
import { ArrowDown } from 'lucide-react'

export function Hero() {
  return (
    <section
      id="top"
      className="relative flex min-h-[100svh] flex-col justify-end overflow-hidden bg-ink text-ink-foreground"
    >
      <Image
        src="/images/hero.png"
        alt="Olea's candlelit dining room with leather banquettes and a glowing wood-fired oven"
        fill
        priority
        sizes="100vw"
        className="object-cover"
      />
      <div
        aria-hidden="true"
        className="absolute inset-0 bg-gradient-to-t from-ink via-ink/40 to-ink/30"
      />

      <div className="relative mx-auto w-full max-w-7xl px-5 pb-10 pt-32 md:px-8 md:pb-14">
        <div className="flex flex-col gap-8 md:flex-row md:items-end md:justify-between">
          <div className="max-w-md">
            <p className="text-xs uppercase tracking-[0.25em] text-ink-foreground/70">
              Wood-fired Mediterranean · Since 2014
            </p>
            <p className="mt-4 text-pretty text-lg leading-relaxed text-ink-foreground/90 md:text-xl">
              Seasonal plates cooked over olive wood and oak, natural wines, and
              a long table that always has room for one more.
            </p>
          </div>

          <div className="flex flex-wrap gap-3">
            <a
              href="#reserve"
              className="inline-flex h-12 items-center rounded-full bg-primary px-7 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
            >
              Reserve a Table
            </a>
            <a
              href="#menu"
              className="inline-flex h-12 items-center rounded-full border border-ink-foreground/40 px-7 text-sm font-medium transition-colors hover:bg-ink-foreground hover:text-ink"
            >
              View the Menu
            </a>
          </div>
        </div>

        <h1 className="mt-10 font-serif text-[26vw] leading-[0.8] tracking-tighter md:mt-12 md:text-[19vw] xl:text-[16rem]">
          Olea
          <span className="sr-only"> — Wood-Fired Mediterranean Kitchen</span>
        </h1>

        <a
          href="#story"
          className="mt-8 inline-flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-ink-foreground/70 transition-colors hover:text-ink-foreground"
        >
          <ArrowDown className="size-4" aria-hidden="true" />
          Scroll to discover
        </a>
      </div>
    </section>
  )
}
