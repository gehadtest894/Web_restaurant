import Image from 'next/image'

const dishes = [
  {
    name: 'Charred Octopus',
    note: 'Smoked paprika, crushed potato, salsa verde',
    src: '/images/dish-octopus.png',
    alt: 'Charred octopus with potatoes and salsa verde on a ceramic plate',
  },
  {
    name: 'Lamb Pappardelle',
    note: 'Slow-braised ragù, aged pecorino',
    src: '/images/dish-pasta.png',
    alt: 'Hand-rolled pappardelle with lamb ragù and shaved pecorino',
  },
  {
    name: 'Fire Flatbread',
    note: "Whipped feta, wildflower honey, za'atar",
    src: '/images/dish-bread.png',
    alt: 'Blistered flatbread with whipped feta, honey and za’atar',
  },
  {
    name: 'Olive Oil Cake',
    note: 'Roasted figs, mascarpone',
    src: '/images/dish-dessert.png',
    alt: 'Olive oil cake with roasted figs and mascarpone cream',
  },
]

export function Signatures() {
  return (
    <section
      aria-labelledby="signatures-heading"
      className="bg-ink py-20 text-ink-foreground md:py-28"
    >
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <h2
            id="signatures-heading"
            className="font-serif text-4xl leading-tight md:text-6xl"
          >
            From the hearth
          </h2>
          <p className="max-w-sm text-ink-foreground/70">
            The dishes our regulars won&apos;t let us take off the menu.
          </p>
        </div>

        <ul className="mt-12 grid gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-4">
          {dishes.map((dish, i) => (
            <li
              key={dish.name}
              className={i % 2 === 1 ? 'lg:translate-y-12' : undefined}
            >
              <div className="group relative aspect-[3/4] overflow-hidden rounded-lg">
                <Image
                  src={dish.src}
                  alt={dish.alt}
                  fill
                  sizes="(min-width: 1024px) 25vw, (min-width: 640px) 50vw, 100vw"
                  className="object-cover transition-transform duration-700 group-hover:scale-105"
                />
              </div>
              <h3 className="mt-5 font-serif text-2xl">{dish.name}</h3>
              <p className="mt-1 text-sm text-ink-foreground/65">{dish.note}</p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
