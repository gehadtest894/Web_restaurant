'use client'

import { useEffect, useState } from 'react'
import { Menu, X } from 'lucide-react'
import { cn } from '@/lib/utils'

const links = [
  { href: '#story', label: 'Our Story' },
  { href: '#menu', label: 'Menu' },
  { href: '#visit', label: 'Visit' },
]

export function SiteHeader() {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40)
    onScroll()
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const solid = scrolled || open

  return (
    <header
      className={cn(
        'fixed inset-x-0 top-0 z-50 transition-colors duration-300',
        solid
          ? 'bg-background/95 text-foreground shadow-[0_1px_0_var(--border)] backdrop-blur'
          : 'bg-transparent text-ink-foreground',
      )}
    >
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5 md:h-20 md:px-8">
        <a href="#top" className="font-serif text-2xl tracking-tight">
          Olea
        </a>

        <nav aria-label="Primary" className="hidden md:block">
          <ul className="flex items-center gap-10 text-sm">
            {links.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  className="opacity-85 transition-opacity hover:opacity-100"
                >
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div className="flex items-center gap-2">
          <a
            href="#reserve"
            className={cn(
              'hidden h-10 items-center rounded-full border px-5 text-sm font-medium transition-colors sm:inline-flex',
              solid
                ? 'border-primary bg-primary text-primary-foreground hover:bg-primary/90'
                : 'border-ink-foreground/50 hover:bg-ink-foreground hover:text-ink',
            )}
          >
            Book a Table
          </a>
          <button
            type="button"
            className="inline-flex size-10 items-center justify-center md:hidden"
            aria-expanded={open}
            aria-controls="mobile-nav"
            onClick={() => setOpen((v) => !v)}
          >
            {open ? <X className="size-5" /> : <Menu className="size-5" />}
            <span className="sr-only">{open ? 'Close menu' : 'Open menu'}</span>
          </button>
        </div>
      </div>

      {open && (
        <nav
          id="mobile-nav"
          aria-label="Mobile"
          className="border-t border-border bg-background px-5 pb-6 md:hidden"
        >
          <ul className="flex flex-col">
            {[...links, { href: '#reserve', label: 'Book a Table' }].map(
              (link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    onClick={() => setOpen(false)}
                    className="block border-b border-border py-4 font-serif text-2xl"
                  >
                    {link.label}
                  </a>
                </li>
              ),
            )}
          </ul>
        </nav>
      )}
    </header>
  )
}
