import { Phone, Mail } from 'lucide-react'

export function Reserve() {
  return (
    <section id="reserve" className="scroll-mt-20 px-5 md:px-8">
      <div className="mx-auto max-w-7xl overflow-hidden rounded-2xl bg-primary px-6 py-16 text-primary-foreground md:px-16 md:py-24">
        <div className="grid gap-10 md:grid-cols-2 md:items-end">
          <div>
            <p className="text-xs uppercase tracking-[0.25em] text-primary-foreground/75">
              Reservations
            </p>
            <h2 className="mt-5 text-balance font-serif text-5xl leading-[0.95] md:text-7xl">
              Save a seat by the fire.
            </h2>
          </div>

          <div className="flex flex-col gap-6">
            <p className="text-pretty text-lg leading-relaxed text-primary-foreground/85">
              We book 30 days ahead and always hold the bar and chef&apos;s
              counter for walk-ins. For parties of 8 or more, or private
              dining in the cellar room, get in touch directly.
            </p>
            <div className="flex flex-col gap-3 sm:flex-row">
              <a
                href="tel:+14155550142"
                className="inline-flex h-12 items-center justify-center gap-2 rounded-full bg-ink px-7 text-sm font-medium text-ink-foreground transition-colors hover:bg-ink/85"
              >
                <Phone className="size-4" aria-hidden="true" />
                (415) 555-0142
              </a>
              <a
                href="mailto:hello@olea.kitchen?subject=Reservation%20request"
                className="inline-flex h-12 items-center justify-center gap-2 rounded-full border border-primary-foreground/50 px-7 text-sm font-medium transition-colors hover:bg-primary-foreground hover:text-primary"
              >
                <Mail className="size-4" aria-hidden="true" />
                hello@olea.kitchen
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
