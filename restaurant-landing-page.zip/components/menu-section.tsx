'use client'

import { useState } from 'react'
import { cn } from '@/lib/utils'

type Item = { name: string; description: string; price: string; tag?: string }

const menu: Record<string, Item[]> = {
  'To Start': [
    { name: 'Fire Flatbread', description: "Whipped feta, wildflower honey, za'atar", price: '14', tag: 'V' },
    { name: 'Marinated Olives', description: 'Orange peel, fennel, house-pressed oil', price: '7', tag: 'VG' },
    { name: 'Burrata', description: 'Blistered tomatoes, basil oil, grilled sourdough', price: '17', tag: 'V' },
    { name: 'Charred Octopus', description: 'Smoked paprika, crushed potato, salsa verde', price: '22' },
    { name: 'Crudo of the Day', description: 'Citrus, chili, Cretan sea salt', price: '19' },
    { name: 'Ember Carrots', description: 'Labneh, dukkah, carrot-top pesto', price: '13', tag: 'V' },
  ],
  Mains: [
    { name: 'Lamb Pappardelle', description: 'Slow-braised ragù, aged pecorino', price: '29' },
    { name: 'Whole Grilled Branzino', description: 'Lemon, capers, wild herbs', price: '38' },
    { name: 'Wood-Roasted Half Chicken', description: 'Chickpeas, preserved lemon, harissa', price: '32' },
    { name: 'Dry-Aged Ribeye', description: 'Bone marrow butter, charred onions', price: '54' },
    { name: 'Saffron Risotto', description: 'Spring peas, mint, parmigiano', price: '26', tag: 'V' },
    { name: 'Smoked Eggplant', description: 'Tahini, pomegranate, crispy shallots', price: '24', tag: 'VG' },
  ],
  Dessert: [
    { name: 'Olive Oil Cake', description: 'Roasted figs, mascarpone', price: '12', tag: 'V' },
    { name: 'Dark Chocolate Tart', description: 'Sea salt, crème fraîche', price: '13', tag: 'V' },
    { name: 'Honey Panna Cotta', description: 'Thyme, poached pear', price: '11' },
    { name: 'Affogato', description: 'Vanilla gelato, espresso, amaro', price: '10', tag: 'V' },
  ],
}

const categories = Object.keys(menu)

export function MenuSection() {
  const [active, setActive] = useState(categories[0])

  return (
    <section id="menu" className="scroll-mt-20 py-20 md:py-32 lg:pt-44">
      <div className="mx-auto max-w-5xl px-5 md:px-8">
        <div className="text-center">
          <p className="text-xs uppercase tracking-[0.25em] text-primary">
            The Menu
          </p>
          <h2 className="mt-5 font-serif text-4xl md:text-6xl">
            Tonight at Olea
          </h2>
          <p className="mx-auto mt-4 max-w-md text-muted-foreground">
            Designed for sharing. Our menu shifts with the seasons &mdash;
            ask your server about today&apos;s catch.
          </p>
        </div>

        <div
          role="tablist"
          aria-label="Menu categories"
          className="mx-auto mt-12 flex w-fit gap-1 rounded-full border border-border bg-card p-1"
        >
          {categories.map((cat) => (
            <button
              key={cat}
              type="button"
              role="tab"
              id={`tab-${cat}`}
              aria-selected={active === cat}
              aria-controls={`panel-${cat}`}
              onClick={() => setActive(cat)}
              className={cn(
                'h-10 rounded-full px-5 text-sm font-medium transition-colors',
                active === cat
                  ? 'bg-foreground text-background'
                  : 'text-muted-foreground hover:text-foreground',
              )}
            >
              {cat}
            </button>
          ))}
        </div>

        <ul
          role="tabpanel"
          id={`panel-${active}`}
          aria-labelledby={`tab-${active}`}
          className="mt-12 grid gap-x-16 md:grid-cols-2"
        >
          {menu[active].map((item) => (
            <li key={item.name} className="border-b border-border py-6">
              <div className="flex items-baseline gap-3">
                <h3 className="font-serif text-xl md:text-2xl">{item.name}</h3>
                {item.tag && (
                  <span className="rounded-sm border border-primary/40 px-1.5 text-[10px] font-semibold tracking-wider text-primary">
                    {item.tag}
                  </span>
                )}
                <span
                  aria-hidden="true"
                  className="flex-1 translate-y-[-4px] border-b border-dotted border-muted-foreground/40"
                />
                <span className="font-serif text-xl">
                  <span className="sr-only">Price: </span>${item.price}
                </span>
              </div>
              <p className="mt-1.5 text-sm text-muted-foreground">
                {item.description}
              </p>
            </li>
          ))}
        </ul>

        <p className="mt-8 text-center text-xs text-muted-foreground">
          V &mdash; vegetarian · VG &mdash; vegan · Please let us know of any
          allergies.
        </p>
      </div>
    </section>
  )
}
