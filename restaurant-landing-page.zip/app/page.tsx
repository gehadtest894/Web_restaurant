import { SiteHeader } from '@/components/site-header'
import { Hero } from '@/components/hero'
import { About } from '@/components/about'
import { MenuSection } from '@/components/menu-section'
import { Signatures } from '@/components/signatures'
import { Reserve } from '@/components/reserve'
import { Visit } from '@/components/visit'
import { SiteFooter } from '@/components/site-footer'

export default function Page() {
  return (
    <>
      <SiteHeader />
      <main>
        <Hero />
        <About />
        <Signatures />
        <MenuSection />
        <Reserve />
        <Visit />
      </main>
      <SiteFooter />
    </>
  )
}
